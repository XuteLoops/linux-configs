#!/usr/bin/env bash
# 12-misc.sh — small quality-of-life environment tweaks.

alias_vim_to_nvim() {
    if ! is_pkg_installed neovim; then
        pkg_install neovim
    fi

    local profile_script="/etc/profile.d/nvim-alias.sh"
    cat > "$profile_script" <<'EOF'
# Added by system-optimizations: alias vim to nvim system-wide.
alias vim='nvim'
EOF
    chmod +x "$profile_script"
    log_success "Aliased vim -> nvim system-wide via $profile_script"
    log_info "Note: aliases in /etc/profile.d only apply to interactive login shells."
}
